export interface Config {
  port: number;
}
