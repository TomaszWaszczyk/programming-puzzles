const CONFIGURATION_TYPES = {
  Config: Symbol.for("Config"),
};

export { CONFIGURATION_TYPES };
