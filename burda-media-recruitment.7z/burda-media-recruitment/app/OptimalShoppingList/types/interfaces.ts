export interface Item {
  name: string;
  review_rating: number;
  price: number;
}
